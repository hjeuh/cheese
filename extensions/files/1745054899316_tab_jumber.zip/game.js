const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let player, gravity, jumpStrength, speed, score, platforms, gameRunning;

function resetGame() {
  player = {
    x: 50,
    y: 100,
    width: 10,
    height: 10,
    yVel: 0,
    jumping: false
  };

  gravity = 0.5;
  jumpStrength = -7;
  speed = 2;
  score = 0;
  gameRunning = false;

  platforms = [
    { x: 0, y: 120, width: 100, height: 10 },
    { x: 150, y: 90, width: 60, height: 10 },
    { x: 250, y: 110, width: 60, height: 10 }
  ];

  drawStartScreen();
}

function drawStartScreen() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'black';
  ctx.font = '16px Arial';
  ctx.fillText('Press SPACE to Start', 70, 75);
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw player
  ctx.fillStyle = 'black';
  ctx.fillRect(player.x, player.y, player.width, player.height);

  // Draw platforms
  ctx.fillStyle = 'gray';
  for (let plat of platforms) {
    ctx.fillRect(plat.x, plat.y, plat.width, plat.height);
  }

  // Draw score
  ctx.fillStyle = 'blue';
  ctx.font = '12px Arial';
  ctx.fillText(`Score: ${score}`, 5, 15);
}

function update() {
  if (!gameRunning) return;

  player.yVel += gravity;
  player.y += player.yVel;

  for (let plat of platforms) {
    plat.x -= speed;
    if (
      player.y + player.height >= plat.y &&
      player.y + player.height <= plat.y + player.yVel + 1 &&
      player.x + player.width > plat.x &&
      player.x < plat.x + plat.width
    ) {
      player.y = plat.y - player.height;
      player.yVel = 0;
      player.jumping = false;
    }
  }

  // Remove platforms offscreen, add new ones
  if (platforms.length && platforms[0].x + platforms[0].width < 0) {
    platforms.shift();
    score++;
  }

  while (platforms[platforms.length - 1].x + platforms[platforms.length - 1].width < canvas.width) {
    const lastY = platforms[platforms.length - 1].y;
    const newY = Math.max(50, Math.min(120, lastY + Math.floor(Math.random() * 41 - 20)));
    const newWidth = 50 + Math.random() * 30;
    platforms.push({
      x: platforms[platforms.length - 1].x + 100,
      y: newY,
      width: newWidth,
      height: 10
    });
  }

  // Game Over condition
  if (player.y > canvas.height) {
    ctx.fillStyle = 'red';
    ctx.font = '20px Arial';
    ctx.fillText('Game Over', 90, 75);
    ctx.font = '12px Arial';
    ctx.fillText('Press R to Restart', 95, 95);
    gameRunning = false;
    return;
  }

  draw();
  requestAnimationFrame(update);
}

window.addEventListener('keydown', function(e) {
  if (e.code === 'Space') {
    if (!gameRunning) {
      gameRunning = true;
      update();
    } else if (!player.jumping) {
      player.yVel = jumpStrength;
      player.jumping = true;
    }
  } else if (e.code === 'KeyR') {
    resetGame();
  }
});

resetGame();
