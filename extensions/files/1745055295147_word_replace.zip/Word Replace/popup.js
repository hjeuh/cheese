document.getElementById('swap').addEventListener('click', () => {
  const find = document.getElementById('find').value;
  const replace = document.getElementById('replace').value;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (find, replace) => {
        const regex = new RegExp(find, 'gi');

        function walk(node) {
          // Skip certain elements
          if (['SCRIPT', 'STYLE', 'IFRAME', 'NOSCRIPT'].includes(node.nodeName)) return;

          if (node.nodeType === 3) {
            // Text node
            node.textContent = node.textContent.replace(regex, replace);
          } else {
            // Recurse
            for (let child of node.childNodes) {
              walk(child);
            }
          }
        }

        walk(document.body);
      },
      args: [find, replace]
    });
  });
});
